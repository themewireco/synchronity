<?php
/**
 * Cart endpoints:
 *   POST   /connector/cart
 *   GET    /connector/cart/{id}
 *   POST   /connector/cart/{id}/items
 *   DELETE /connector/cart/{id}/items/{item_id}
 *   POST   /connector/cart/{id}/coupon
 */

defined( 'ABSPATH' ) || exit;

class AgentMesh_Cart {

	/** Transient TTL in seconds (24 hours). */
	const CART_TTL = 86400;

	/** Transient key prefix. */
	const TRANSIENT_PREFIX = 'agentmesh_cart_';

	private AgentMesh_Auth $auth;

	public function __construct() {
		$this->auth = new AgentMesh_Auth();
	}

	public function register_routes(): void {
		$ns = AGENTMESH_REST_NAMESPACE;

		register_rest_route( $ns, '/connector/cart', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'create_cart' ],
			'permission_callback' => [ $this->auth, 'verify_connector_key' ],
		] );

		register_rest_route( $ns, '/connector/cart/(?P<cart_id>[^/]+)', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_cart' ],
			'permission_callback' => [ $this->auth, 'verify_connector_key' ],
		] );

		register_rest_route( $ns, '/connector/cart/(?P<cart_id>[^/]+)/items', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'add_item' ],
			'permission_callback' => [ $this->auth, 'verify_connector_key' ],
		] );

		register_rest_route( $ns, '/connector/cart/(?P<cart_id>[^/]+)/items/(?P<item_id>[^/]+)', [
			'methods'             => WP_REST_Server::DELETABLE,
			'callback'            => [ $this, 'remove_item' ],
			'permission_callback' => [ $this->auth, 'verify_connector_key' ],
		] );

		register_rest_route( $ns, '/connector/cart/(?P<cart_id>[^/]+)/coupon', [
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => [ $this, 'apply_coupon' ],
			'permission_callback' => [ $this->auth, 'verify_connector_key' ],
		] );
	}

	// ─────────────────────────────────────────────────────────────────
	// POST /connector/cart
	// ─────────────────────────────────────────────────────────────────

	public function create_cart( WP_REST_Request $request ): WP_REST_Response {
		if ( ! get_option( 'agentmesh_allow_cart', true ) ) {
			return $this->forbidden_response( $request, 'Cart management is disabled.' );
		}

		$currency = strtoupper( sanitize_text_field( $request->get_param( 'currency' ) ?: get_woocommerce_currency() ) );
		$cart_id  = $this->generate_cart_id();
		$site_id  = (string) get_option( 'agentmesh_site_id', '' );

		$cart_data = $this->empty_cart_data( $cart_id, $site_id, $currency );
		$this->save_cart( $cart_id, $cart_data );

		$response = new WP_REST_Response( $cart_data, 201 );
		return AgentMesh_Auth::echo_request_id( $request, $response );
	}

	// ─────────────────────────────────────────────────────────────────
	// GET /connector/cart/{id}
	// ─────────────────────────────────────────────────────────────────

	public function get_cart( WP_REST_Request $request ): WP_REST_Response {
		$cart_id   = sanitize_text_field( $request->get_param( 'cart_id' ) );
		$cart_data = $this->load_cart( $cart_id );

		if ( false === $cart_data ) {
			return $this->not_found_response( $request, 'Cart not found.' );
		}

		if ( $this->is_expired( $cart_data ) ) {
			$this->delete_cart( $cart_id );
			return $this->gone_response( $request );
		}

		$response = new WP_REST_Response( $cart_data, 200 );
		return AgentMesh_Auth::echo_request_id( $request, $response );
	}

	// ─────────────────────────────────────────────────────────────────
	// POST /connector/cart/{id}/items
	// ─────────────────────────────────────────────────────────────────

	public function add_item( WP_REST_Request $request ): WP_REST_Response {
		$cart_id = sanitize_text_field( $request->get_param( 'cart_id' ) );
		[ $cart_data, $err ] = $this->resolve_cart( $cart_id );
		if ( $err ) return AgentMesh_Auth::echo_request_id( $request, $err );

		$product_id = (int) $request->get_param( 'product_id' );
		$quantity   = max( 1, (int) $request->get_param( 'quantity' ) );
		$variant_id = $request->get_param( 'variant_id' ) ? (int) $request->get_param( 'variant_id' ) : null;

		$product = wc_get_product( $variant_id ?: $product_id );
		if ( ! $product ) {
			return $this->not_found_response( $request, 'Product not found.' );
		}

		$currency   = $cart_data['currency'];
		$unit_price = (float) ( $variant_id ? $product->get_price() : wc_get_product( $product_id )->get_price() );
		$line_total = $unit_price * $quantity;

		$item_id = 'item_' . $this->generate_short_id();

		$item = [
			'item_id'    => $item_id,
			'product_id' => (string) $product_id,
			'title'      => $product->get_name(),
			'quantity'   => $quantity,
			'unit_price' => [ 'amount' => number_format( $unit_price, 2, '.', '' ), 'currency' => $currency ],
			'line_total' => [ 'amount' => number_format( $line_total, 2, '.', '' ), 'currency' => $currency ],
		];
		if ( $variant_id ) {
			$item['variant_id'] = (string) $variant_id;
		}

		$cart_data['items'][] = $item;
		$cart_data = $this->recalculate( $cart_data );
		$this->save_cart( $cart_id, $cart_data );

		$response = new WP_REST_Response( $cart_data, 200 );
		return AgentMesh_Auth::echo_request_id( $request, $response );
	}

	// ─────────────────────────────────────────────────────────────────
	// DELETE /connector/cart/{id}/items/{item_id}
	// ─────────────────────────────────────────────────────────────────

	public function remove_item( WP_REST_Request $request ): WP_REST_Response {
		$cart_id = sanitize_text_field( $request->get_param( 'cart_id' ) );
		$item_id = sanitize_text_field( $request->get_param( 'item_id' ) );

		[ $cart_data, $err ] = $this->resolve_cart( $cart_id );
		if ( $err ) return AgentMesh_Auth::echo_request_id( $request, $err );

		$found = false;
		$cart_data['items'] = array_values( array_filter(
			$cart_data['items'],
			function ( $item ) use ( $item_id, &$found ) {
				if ( $item['item_id'] === $item_id ) { $found = true; return false; }
				return true;
			}
		) );

		if ( ! $found ) {
			return $this->not_found_response( $request, 'Cart item not found.' );
		}

		$cart_data = $this->recalculate( $cart_data );
		$this->save_cart( $cart_id, $cart_data );

		$response = new WP_REST_Response( $cart_data, 200 );
		return AgentMesh_Auth::echo_request_id( $request, $response );
	}

	// ─────────────────────────────────────────────────────────────────
	// POST /connector/cart/{id}/coupon
	// ─────────────────────────────────────────────────────────────────

	public function apply_coupon( WP_REST_Request $request ): WP_REST_Response {
		$cart_id = sanitize_text_field( $request->get_param( 'cart_id' ) );
		$code    = sanitize_text_field( $request->get_param( 'code' ) );

		[ $cart_data, $err ] = $this->resolve_cart( $cart_id );
		if ( $err ) return AgentMesh_Auth::echo_request_id( $request, $err );

		if ( empty( $code ) ) {
			$response = new WP_REST_Response(
				AgentMesh_Auth::error_response( 'INVALID_REQUEST', 'Coupon code is required.' ),
				400
			);
			return AgentMesh_Auth::echo_request_id( $request, $response );
		}

		$coupon = new WC_Coupon( $code );
		if ( ! $coupon->get_id() ) {
			$response = new WP_REST_Response(
				AgentMesh_Auth::error_response( 'INVALID_COUPON', 'Coupon code is invalid or expired.' ),
				400
			);
			return AgentMesh_Auth::echo_request_id( $request, $response );
		}

		// Validate coupon dates
		if ( $coupon->get_date_expires() && $coupon->get_date_expires()->getTimestamp() < time() ) {
			$response = new WP_REST_Response(
				AgentMesh_Auth::error_response( 'COUPON_EXPIRED', 'This coupon has expired.' ),
				400
			);
			return AgentMesh_Auth::echo_request_id( $request, $response );
		}

		$subtotal       = $this->cart_subtotal_float( $cart_data );
		$discount_amount = 0.0;
		$currency        = $cart_data['currency'];

		$discount_type = $coupon->get_discount_type();
		if ( 'percent' === $discount_type ) {
			$discount_amount = $subtotal * ( (float) $coupon->get_amount() / 100 );
		} else {
			$discount_amount = min( (float) $coupon->get_amount(), $subtotal );
		}

		// De-duplicate coupon applications
		$cart_data['discounts'] = array_values( array_filter(
			$cart_data['discounts'] ?? [],
			fn( $d ) => strtolower( $d['code'] ) !== strtolower( $code )
		) );

		$cart_data['discounts'][] = [
			'code'          => strtoupper( $code ),
			'description'   => $coupon->get_description() ?: null,
			'type'          => 'percent' === $discount_type ? 'percentage' : 'fixed',
			'coupon_value'  => (float) $coupon->get_amount(),
			'amount_saved'  => [ 'amount' => number_format( $discount_amount, 2, '.', '' ), 'currency' => $currency ],
			'amount'        => [ 'amount' => number_format( $discount_amount, 2, '.', '' ), 'currency' => $currency ],
		];

		$cart_data = $this->recalculate( $cart_data );
		$this->save_cart( $cart_id, $cart_data );

		$response = new WP_REST_Response( $cart_data, 200 );
		return AgentMesh_Auth::echo_request_id( $request, $response );
	}

	// ─────────────────────────────────────────────────────────────────
	// Internal helpers
	// ─────────────────────────────────────────────────────────────────

	private function generate_cart_id(): string {
		return 'cart_' . bin2hex( random_bytes( 12 ) );
	}

	private function generate_short_id(): string {
		return bin2hex( random_bytes( 6 ) );
	}

	private function empty_cart_data( string $cart_id, string $site_id, string $currency ): array {
		$currency = strtoupper( $currency );
		return [
			'cart_id'    => $cart_id,
			'site_id'    => $site_id,
			'items'      => [],
			'discounts'  => [],
			'subtotal'   => [ 'amount' => '0.00', 'currency' => $currency ],
			'total'      => [ 'amount' => '0.00', 'currency' => $currency ],
			'currency'   => $currency,
			'expires_at' => gmdate( 'Y-m-d\TH:i:s\Z', time() + self::CART_TTL ),
		];
	}

	private function recalculate( array $cart_data ): array {
		$currency = $cart_data['currency'];
		$subtotal = 0.0;
		foreach ( $cart_data['items'] as $item ) {
			$subtotal += (float) $item['line_total']['amount'];
		}

		$discount_total = 0.0;
		foreach ( $cart_data['discounts'] ?? [] as $discount ) {
			$discount_total += (float) $discount['amount']['amount'];
		}

		$total = max( 0.0, $subtotal - $discount_total );

		$cart_data['subtotal'] = [ 'amount' => number_format( $subtotal, 2, '.', '' ), 'currency' => $currency ];
		$cart_data['total']    = [ 'amount' => number_format( $total, 2, '.', '' ), 'currency' => $currency ];

		return $cart_data;
	}

	private function cart_subtotal_float( array $cart_data ): float {
		return (float) ( $cart_data['subtotal']['amount'] ?? '0.00' );
	}

	private function save_cart( string $cart_id, array $cart_data ): void {
		set_transient( self::TRANSIENT_PREFIX . $cart_id, $cart_data, self::CART_TTL );
	}

	private function load_cart( string $cart_id ): array|false {
		return get_transient( self::TRANSIENT_PREFIX . $cart_id );
	}

	private function delete_cart( string $cart_id ): void {
		delete_transient( self::TRANSIENT_PREFIX . $cart_id );
	}

	private function is_expired( array $cart_data ): bool {
		if ( empty( $cart_data['expires_at'] ) ) return false;
		return strtotime( $cart_data['expires_at'] ) < time();
	}

	/**
	 * Load and validate a cart, returning [cart_data, null] or [null, WP_REST_Response].
	 */
	private function resolve_cart( string $cart_id ): array {
		if ( ! get_option( 'agentmesh_allow_cart', true ) ) {
			return [ null, new WP_REST_Response(
				AgentMesh_Auth::error_response( 'FORBIDDEN', 'Cart management is disabled.' ),
				403
			) ];
		}

		$cart_data = $this->load_cart( $cart_id );
		if ( false === $cart_data ) {
			return [ null, new WP_REST_Response(
				AgentMesh_Auth::error_response( 'NOT_FOUND', 'Cart not found.' ),
				404
			) ];
		}

		if ( $this->is_expired( $cart_data ) ) {
			$this->delete_cart( $cart_id );
			return [ null, new WP_REST_Response(
				AgentMesh_Auth::error_response( 'CART_EXPIRED', 'Cart session has expired.' ),
				410
			) ];
		}

		return [ $cart_data, null ];
	}

	private function not_found_response( WP_REST_Request $request, string $message ): WP_REST_Response {
		$r = new WP_REST_Response( AgentMesh_Auth::error_response( 'NOT_FOUND', $message ), 404 );
		return AgentMesh_Auth::echo_request_id( $request, $r );
	}

	private function forbidden_response( WP_REST_Request $request, string $message ): WP_REST_Response {
		$r = new WP_REST_Response( AgentMesh_Auth::error_response( 'FORBIDDEN', $message ), 403 );
		return AgentMesh_Auth::echo_request_id( $request, $r );
	}

	private function gone_response( WP_REST_Request $request ): WP_REST_Response {
		$r = new WP_REST_Response( AgentMesh_Auth::error_response( 'CART_EXPIRED', 'Cart session has expired.' ), 410 );
		return AgentMesh_Auth::echo_request_id( $request, $r );
	}
}
