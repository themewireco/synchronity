<?php
/**
 * Admin Settings — WooCommerce Settings tab for AgentMesh.
 */

defined( 'ABSPATH' ) || exit;

class AgentMesh_Settings {

	public function __construct() {
		add_filter( 'woocommerce_settings_tabs_array', [ $this, 'add_settings_tab' ], 50 );
		add_action( 'woocommerce_settings_tabs_agentmesh', [ $this, 'output_settings' ] );
		add_action( 'woocommerce_update_options_agentmesh', [ $this, 'save_settings' ] );
		add_action( 'woocommerce_settings_tabs_agentmesh', [ $this, 'maybe_generate_site_id' ] );
	}

	public function add_settings_tab( array $tabs ): array {
		$tabs['agentmesh'] = __( 'AgentMesh', 'agentmesh-woocommerce' );
		return $tabs;
	}

	public function output_settings(): void {
		WC_Admin_Settings::output_fields( $this->get_settings() );
	}

	public function save_settings(): void {
		WC_Admin_Settings::save_fields( $this->get_settings() );
	}

	/**
	 * Auto-generate a site ID on first load if one doesn't exist.
	 */
	public function maybe_generate_site_id(): void {
		if ( ! get_option( 'agentmesh_site_id' ) ) {
			update_option( 'agentmesh_site_id', 'site_' . bin2hex( random_bytes( 8 ) ) );
		}
	}

	public function get_settings(): array {
		return [
			[
				'title' => __( 'AgentMesh Settings', 'agentmesh-woocommerce' ),
				'type'  => 'title',
				'desc'  => __( 'Connect your WooCommerce store to the AgentMesh network.', 'agentmesh-woocommerce' ),
				'id'    => 'agentmesh_settings_section',
			],

			[
				'title'   => __( 'Enable AgentMesh', 'agentmesh-woocommerce' ),
				'type'    => 'checkbox',
				'desc'    => __( 'Enable the AgentMesh connector API on this store.', 'agentmesh-woocommerce' ),
				'id'      => 'agentmesh_enabled',
				'default' => 'yes',
			],

			[
				'title'       => __( 'Gateway URL', 'agentmesh-woocommerce' ),
				'type'        => 'url',
				'desc'        => __( 'The base URL of your AgentMesh Gateway instance (e.g. https://gateway.agentmesh.io).', 'agentmesh-woocommerce' ),
				'id'          => 'agentmesh_gateway_url',
				'placeholder' => 'https://gateway.agentmesh.io',
				'css'         => 'min-width:350px;',
			],

			[
				'title'       => __( 'Connector Key', 'agentmesh-woocommerce' ),
				'type'        => 'password',
				'desc'        => __( 'The shared secret key the Gateway uses to authenticate requests to this connector.', 'agentmesh-woocommerce' ),
				'id'          => 'agentmesh_connector_key',
				'placeholder' => 'amck_...',
				'css'         => 'min-width:350px;',
			],

			[
				'title'   => __( 'Site ID', 'agentmesh-woocommerce' ),
				'type'    => 'text',
				'desc'    => __( 'Your AgentMesh-assigned site identifier. Auto-generated if empty.', 'agentmesh-woocommerce' ),
				'id'      => 'agentmesh_site_id',
				'css'     => 'min-width:350px;',
			],

			[
				'title' => __( 'Permissions', 'agentmesh-woocommerce' ),
				'type'  => 'title',
				'id'    => 'agentmesh_permissions_section',
			],

			[
				'title'   => __( 'Allow Cart Management', 'agentmesh-woocommerce' ),
				'type'    => 'checkbox',
				'desc'    => __( 'Allow AI agents to create and manage cart sessions on this store.', 'agentmesh-woocommerce' ),
				'id'      => 'agentmesh_allow_cart',
				'default' => 'yes',
			],

			[
				'title'   => __( 'Allow Checkout Execution', 'agentmesh-woocommerce' ),
				'type'    => 'checkbox',
				'desc'    => __( 'Allow AI agents to place orders on behalf of users via delegation tokens.', 'agentmesh-woocommerce' ),
				'id'      => 'agentmesh_allow_checkout',
				'default' => 'yes',
			],

			[
				'title'   => __( 'Read-Only Mode', 'agentmesh-woocommerce' ),
				'type'    => 'checkbox',
				'desc'    => __( 'Restrict the connector to product and manifest reads only. Disables cart and checkout.', 'agentmesh-woocommerce' ),
				'id'      => 'agentmesh_read_only',
				'default' => 'no',
			],

			[
				'type' => 'sectionend',
				'id'   => 'agentmesh_settings_section',
			],
		];
	}
}
