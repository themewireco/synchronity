=== AgentMesh for WooCommerce ===
Contributors: themewire
Tags: agentmesh, ai-commerce, woocommerce, ai-agents
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 8.2
Stable tag: 0.1.0
License: Proprietary

Connect your WooCommerce store to the AgentMesh network — enabling AI agents to discover, search, and purchase from your store.

== Description ==

AgentMesh for WooCommerce implements the AgentMesh Connector Interface, exposing your WooCommerce product catalogue, cart, and checkout to the AgentMesh Gateway. AI agents (Claude, ChatGPT, LangChain, etc.) can then autonomously browse products, manage carts, and place orders on behalf of users.

**Features:**
* Full AMPS-normalised product catalogue API
* Cart session management (create, add/remove items, coupons)
* Checkout execution via buyer delegation tokens
* Order tracking and status
* Webhook delivery for inventory and order events
* Admin settings page under WooCommerce → AgentMesh
* **Phase 6: Automatic Schema Injection** — Automatically injects signed AMPS schema for LLM discovery via IP-based detection

== Installation ==

1. Upload the plugin to `/wp-content/plugins/agentmesh-woocommerce/`
2. Activate the plugin via the 'Plugins' menu in WordPress
3. Navigate to WooCommerce → Settings → AgentMesh
4. Enter your AgentMesh Gateway URL and Connector Key

== Frequently Asked Questions ==

= What is AgentMesh? =
AgentMesh is an AI agentic commerce infrastructure layer. It normalises your WooCommerce store API so AI agents can transact programmatically.

= Is WooCommerce required? =
Yes — WooCommerce 7.0 or higher must be installed and active.

== Changelog ==

= 0.2.0 =
* Phase 6 Schema Injection — Automatic schema injection for LLM discovery
* IP-only detection (works with generic User-Agent from web_fetch)
* Signed schema with public key validation
* 5-minute schema caching to reduce gateway load
* Silent error handling (no user-facing errors if gateway unreachable)

= 0.1.0 =
* Initial release — Phase 1 WooCommerce connector
* Implements all mandatory Connector Interface endpoints
* Full AMPS normalisation layer
